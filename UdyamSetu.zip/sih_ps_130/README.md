# UdyamSetu

A dependency-free full-stack prototype for industrial approval discovery, application tracking, compliance reminders, business profiles, incentives, and department-side review.

## Run locally

Requires Node.js 18 or later.

```sh
npm start
```

Open [http://localhost:3000](http://localhost:3000). The API and static frontend are served by the same local Node.js process. Prototype records persist in `data/store.json`.

## Demo path

1. Use **Build my approval checklist** to enter project details and generate an indicative approval list.
2. Choose an item to create a draft, then submit it from **My approvals**.
3. Open **Review desk** to record a department decision or request information.
4. Return to the applicant view to respond to a query, check notifications, or open the business profile.
5. Add a compliance reminder from **Compliance** and edit business details from **Business profile**.

## Prototype boundary

The approval rules, service dates, incentives, and sample business records are demonstration data. Document attachments in this prototype are recorded by filename; statutory applications, official scheme eligibility, payments, and government system integrations are not live.
